package com.gojek.carparking.service;

import com.gojek.carparking.vo.ParkingParameter;

public interface GoJekParkingService {

	public void doAction(ParkingParameter param);

}
