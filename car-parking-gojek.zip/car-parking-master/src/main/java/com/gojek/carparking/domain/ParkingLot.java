package com.gojek.carparking.domain;

public interface ParkingLot {

	public Long getSpaceId();
}
