package com.gojek.carparking.domain;

public interface Vehicle {

	public String getRegistrationNo();

	public String getColor();
}
