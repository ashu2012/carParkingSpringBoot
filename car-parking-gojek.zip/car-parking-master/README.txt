Car Parking System
__________________

Prerequisite:
To run this application we have to build the application.
We need to have Java 8 and Maven installed to build it.

Goto project root directory and execute
$ mvn clean install

Run the application:

Goto project root directory and execute
$./parking_lot.sh to start the application in interactive mode
or
$./parking_lot.sh <file_path> to execute it taking input from a file
